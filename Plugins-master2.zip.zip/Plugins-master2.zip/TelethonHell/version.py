from telethon import version as ver

__telever__ = ver.__version__

__hellver__ = "α • 1.4.5"
# __hellver__ = "β • 1.5.0"
