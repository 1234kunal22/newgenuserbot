DEVLIST = [
    "1891078417",   # LUCIF3R
    "2097320259",   # xABHISH3K
    "1329105215",   # ABHISHEKSINGH
]

HARMFUL = [
    "base64",
    "bash",
    "get_me()",
    "phone",
    "os.system",
    "sys.stdout",
    "sys.stderr",
    "subprocess",
    "session.save()",
    "STRING_SESSION",
    "INSTAGRAM_SESSION",
    "DATABASE_URL",
    "BOT_TOKEN",
    "API_HASH",
    "APP_ID",
    "HEROKU_API_KEY",
]

INVALID_UPLOAD = ["WAR-TBot.session-journal", "WAR-TBot.session", "insta/settings.json"]
